#include <stdio.h>

typedef struct {
    int width;
    int height;
    char* canvas;
    int cursor_x;
    int cursor_y;
    char current_char;
} EditorState;

EditorState g_editor = {80, 24, NULL, 1, 1, '#'};

void init_editor_vars() {
    printf("Инициализация переменных визуального редактора SIK2D\n");
    printf("Ширина: %d, Высота: %d\n", g_editor.width, g_editor.height);
    printf("Курсор: (%d,%d), Символ: '%c'\n", 
           g_editor.cursor_x, g_editor.cursor_y, g_editor.current_char);
}